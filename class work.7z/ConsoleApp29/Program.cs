﻿using ConsoleApp29;

namespace ConsoleApp29
{
    class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public Product(string name, decimal price)
        {
            Name = name;
            Price = price;
        }
    }

    class Order
    {
        public int OrderId { get; private set; }
        public string CustomerName { get; private set; }
        public List<Product> Products { get; private set; }
        public decimal TotalCost { get; private set; }

        public Order(int orderId, string customerName)
        {
            OrderId = orderId;
            CustomerName = customerName;
            Products = new List<Product>();
            TotalCost = 0;
        }

        public void AddProduct(Product product)
        {
            Products.Add(product);
            TotalCost += product.Price;
        }

        public void DisplayOrder()
        {
            Console.WriteLine($"Order ID: {OrderId}");
            Console.WriteLine($"имя: {CustomerName}");
            Console.WriteLine("продукты:");
            foreach (var product in Products)
            {
                Console.WriteLine($"- {product.Name}: {product.Price:C}");
            }
            Console.WriteLine($"общая стоимость: {TotalCost:C}");
        }
    }

    class OrderQueue
    {
        private Queue<Order> orders;
        private Stack<Order> completedOrders;

        public OrderQueue()
        {
            orders = new Queue<Order>();
            completedOrders = new Stack<Order>();
        }


        public void AddOrder(Order order)
        {
            orders.Enqueue(order);
            Console.WriteLine($"Order ID {order.OrderId} добавлен в очередь.");
        }
        public Order GetNextOrder()
        {
            if (orders.Count == 0)
            {
                Console.WriteLine("очередь заказов пуста.");
                return null;
            }
            return orders.Dequeue();
        }
        public void CompleteOrder(Order order)
        {
            completedOrders.Push(order);
            Console.WriteLine($"Order ID {order.OrderId} был завершён и отправлен к завершённым заказам.");
        }


        public int OrderCount()
        {
            return orders.Count;
        }


        public int CompletedOrderCount()
        {
            return completedOrders.Count;
        }
    }

    class Program
    {
        static void Main()
        {
            OrderQueue orderQueue = new OrderQueue();


            Order order1 = new Order(1, "Джон");
            order1.AddProduct(new Product("ноутбук", 899.99m));
            orderQueue.AddOrder(order1);

            Order order2 = new Order(2, "Анна");
            order2.AddProduct(new Product("телефон", 499.99m));
            orderQueue.AddOrder(order2);

            Order order3 = new Order(3, "Майк");
            order3.AddProduct(new Product("стул", 299.99m));
            orderQueue.AddOrder(order3);


            Console.WriteLine("\nОбработка заказов:");
            while (orderQueue.OrderCount() > 0)
            {
                Order nextOrder = orderQueue.GetNextOrder();
                if (nextOrder != null)
                {
                    nextOrder.DisplayOrder();
                    Console.WriteLine();
                    orderQueue.CompleteOrder(nextOrder);
                }
            }


            Console.WriteLine($"общее количество завершённых заказов: {orderQueue.CompletedOrderCount()}");
        }
    }
}
