﻿namespace ConsoleApp27
{
    class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public Product(string name, decimal price)
        {
            Name = name;
            Price = price;
        }
    }

    class Order
    {
        public int OrderId { get; private set; }
        public string CustomerName { get; private set; }
        public List<Product> Products { get; private set; }
        public decimal TotalCost { get; private set; }

        public Order(int orderId, string customerName)
        {
            OrderId = orderId;
            CustomerName = customerName;
            Products = new List<Product>();
            TotalCost = 0;
        }

        public void AddProduct(Product product)
        {
            Products.Add(product);
            TotalCost += product.Price; 
        }

        public void DisplayOrder()
        {
            Console.WriteLine($"Order ID: {OrderId}");
            Console.WriteLine($"имя: {CustomerName}");
            Console.WriteLine("продукты:");

            foreach (var product in Products)
            {
                Console.WriteLine($"- {product.Name}: {product.Price:C}");
            }
                Console.WriteLine($"общая стоимость: {TotalCost:C}");
        }
    }

    class Program
    {
        static void Main()
        {

            Order order = new Order(1, "Джон");

            order.AddProduct(new Product("ноутбук", 900.00m));
            order.AddProduct(new Product("мышь", 25.50m));
            order.AddProduct(new Product("клавиатура", 45.75m));

            order.DisplayOrder();
        }
    }
}